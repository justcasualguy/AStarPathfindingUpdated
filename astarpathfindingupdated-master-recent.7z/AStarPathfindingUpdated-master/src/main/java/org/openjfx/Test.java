package org.openjfx;

import org.openjfx.pathfinfing.Map;
import org.openjfx.pathfinfing.MapNode;

import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Vector;

public class Test {
    static public int elemId(int x,int y,int size){
        return y*size+x;
    }



    public static void main(String[] args) {
        int size=20;
        Map map = new Map(size);
        Map m;
        int startX=5;
        int startY=5;
        int endX=3;
        int endY=3;
        MapNode start = map.getNodes().get(elemId(startX,startY,size));
        MapNode end = map.getNodes().get(elemId(endX,endY,size));


        System.out.println(String.format("Start:[%d,%d] End:[%d,%d]", startX, startY, endX, endY));
        System.out.println("============================");
       LinkedList<Integer> wyniki = new LinkedList<>();
        LinkedList<MapNode> result = map.findPath(start, end);
        for(int i=0;i<1;i++) {
            m= new Map(size);
            Map m2= new Map(size);
            LinkedList<MapNode> result2 = map.findPathParameterized2(m,m.getNodes().get(elemId(startX,startY,size)), m.getNodes().get(elemId(endX,endY,size)), 0.6);
            wyniki.add(result2.size());
            System.out.println("Shortest path:");
            System.out.println(result);
            System.out.println("Walked path "+i+":" + result2);
            for(MapNode node:result2){
                for (MapNode node2:node.getNeighbours())
                    node2.setTraversable(true);

            }
            try {
                m2.saveFile(result2);
            }
            catch (Exception e){
                System.out.println(e);
            }
            System.out.println("Path size:" + result2.size());
            map = new Map(size);
        }
        System.out.println("All sizes: ");
        System.out.println(wyniki);

    }
}
